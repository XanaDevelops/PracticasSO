clear
rm -rf disco* ext* res*
make clean
make -j16

./mi_mkfs disco 100000
./prueba_cache_tabla disco "hola"