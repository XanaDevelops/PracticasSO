#!/bin/bash
make clean
make
./mi_mkfs test.dsk 100000
./leer_sf test.dsk
