Práctica entrega extra

Nombres participantes equipo
    Daniel García Vázquez  

Realizado:
    cache LE
    mi_rm_r
    secciones criticas
    mi_rn
    timeval
    verificacion fix tiempos
    mmap()
    mi_cp
    mi_mv

En resumen todo lo opcional se ha implementado, ya sea en la ordinaria en grupo o en solitario.
