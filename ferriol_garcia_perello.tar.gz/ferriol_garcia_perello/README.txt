Práctica niveles 1-6

Nombres participantes equipo
    Josep Ferriol Font     
    Daniel García Vázquez  
    Biel Perelló Perelló

Se han seguido las recomendaciones de los diferentes niveles
En liberar_bloques_inodo() se ha comprimido mediante funciones auxiliares